package week3;
import java.util.Scanner;
//양수 5개를 입력 받아 배열에 저장하고, 가운데 값을 출력하는 프로그램

public class MedianFive {
	public static void main(String args[]) {
		Scanner input = new Scanner(System.in);
		int []arr = new int[5];
		
		for(int i=0; i<5; i++) {
			System.out.println("양수를 입력하세요:");
		}
		
		
	}

}
